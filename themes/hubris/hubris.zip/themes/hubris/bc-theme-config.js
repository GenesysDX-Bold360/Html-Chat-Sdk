var bc = window.bc || {};
bc.themeConfig = {
	labelsAfterInputFields: true,
	placeholdersOnInputFields: false
};
